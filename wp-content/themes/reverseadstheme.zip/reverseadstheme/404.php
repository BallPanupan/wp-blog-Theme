<?php
    get_header();
?>

		<article class="content px-3 py-5 p-md-5">
        <h1>PAGE NOT FOUND</h1>

        <?php
            get_search_form();
        ?>

	    </article>

<?php
    get_footer();
?>
