# Blog Site Template
This is a free blog site template based on Bootstrap 4.

It has a left sidebar and is customizable via CSS variables (custom properties)

Watch the entire creation of this template on scrimba here: or see the conversion of this tempalte to a WordPress theme here: 


## Versions
* 1.0
  * Initial release